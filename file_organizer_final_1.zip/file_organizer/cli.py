"""
cli.py — Command-line interface and main() entry point.
Parses arguments and dispatches to the appropriate module.
"""

import os
import sys
import json
import argparse
from datetime import datetime, timedelta

from .constants import DEFAULT_IGNORE_PATTERNS, OrganizerConfig
from .core import (
    organize_folder, stats_only, print_stats,
    print_stats_only, setup_logger, load_config,
)
from .tags import add_tags, remove_tags, list_tags, load_tags
from .history import undo_last, save_history
from .reports import generate_html_report, generate_csv_report
from .scanner import scan_suspicious, print_scan_results
from .watcher import watch_folder
from .gui import launch_gui

# Optional tqdm
try:
    from tqdm import tqdm
    TQDM_AVAILABLE = True
except ImportError:
    TQDM_AVAILABLE = False


def parse_size(s):
    """Parse size strings like '500KB', '2MB', '1GB' into bytes."""
    s = s.strip().upper()
    for unit, mult in [("TB", 1024**4), ("GB", 1024**3),
                       ("MB", 1024**2), ("KB", 1024), ("B", 1)]:
        if s.endswith(unit):
            return int(float(s[:-len(unit)]) * mult)
    return int(s)


def main():
    parser = argparse.ArgumentParser(
        description="File Organizer — sort files into folders by type",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python -m file_organizer ~/Downloads --dry-run
  python -m file_organizer ~/Downloads --recursive --by-date
  python -m file_organizer ~/Downloads --copy --verify --html-report
  python -m file_organizer ~/Downloads --min-size 1MB --older-than 30
  python -m file_organizer ~/Downloads --ignore "*.tmp" "~*" --stats-only
  python -m file_organizer ~/Downloads --keep-duplicate newest
  python -m file_organizer ~/Downloads --interactive
  python -m file_organizer ~/Downloads --rules '[{"contains":"invoice","category":"Finance"}]'

  Tagging:
  python -m file_organizer ~/Downloads --tag report.pdf budget review
  python -m file_organizer ~/Downloads --untag report.pdf review
  python -m file_organizer ~/Downloads --list-tags
  python -m file_organizer ~/Downloads --search-tag budget
  python -m file_organizer ~/Downloads --search-tag budget review
  python -m file_organizer ~/Downloads --filter-tag budget
  python -m file_organizer ~/Downloads --filter-tag budget review --dry-run
""",
    )

    parser.add_argument("folder", nargs="?", help="Path to the folder to organize")

    # Modes
    parser.add_argument("--dry-run",        action="store_true", help="Preview without moving anything")
    parser.add_argument("--undo",           action="store_true", help="Undo the last organize session")
    parser.add_argument("--watch",          action="store_true", help="Watch folder and auto-organize new files")
    parser.add_argument("--gui",            action="store_true", help="Launch the graphical interface")
    parser.add_argument("--stats-only",     action="store_true", help="Count files by type without moving")
    parser.add_argument("--scan",           action="store_true", help="Scan for suspicious file extensions")
    parser.add_argument("--scan-recursive", action="store_true", help="Scan subfolders for suspicious files")

    # Tagging
    parser.add_argument("--tag",        metavar=("FILE", "TAG"), nargs="+",
                        help="Tag a file: --tag report.pdf budget review")
    parser.add_argument("--untag",      metavar=("FILE", "TAG"), nargs="+",
                        help="Remove tags from a file: --untag report.pdf review")
    parser.add_argument("--list-tags",  action="store_true", help="List all tagged files and their tags")
    parser.add_argument("--search-tag", metavar="TAG", nargs="+",
                        help="Search tagged files by tag(s): --search-tag budget review")
    parser.add_argument("--filter-tag", metavar="TAG", nargs="+",
                        help="Only organize files that have ALL specified tags")

    # Organisation
    parser.add_argument("--recursive",      action="store_true", help="Organize subfolders recursively")
    parser.add_argument("--rename",         action="store_true", help="Prefix filenames with today's date")
    parser.add_argument("--by-date",        action="store_true", help="Organize into Category/YYYY/Month/")
    parser.add_argument("--copy",           action="store_true", help="Copy files instead of moving")
    parser.add_argument("--verify",         action="store_true", help="Checksum-verify each copy/move")
    parser.add_argument("--interactive",    action="store_true", help="Confirm each file move individually")
    parser.add_argument("--config",         metavar="FILE",      help="Path to custom categories JSON")
    parser.add_argument("--keep-duplicate", default="route",
                        choices=["route", "newest", "oldest", "ask"],
                        help="How to handle identical duplicates (default: route)")

    # Filters
    parser.add_argument("--min-size",   metavar="SIZE", help="Skip files smaller than SIZE (e.g. 500KB)")
    parser.add_argument("--max-size",   metavar="SIZE", help="Skip files larger than SIZE (e.g. 1GB)")
    parser.add_argument("--older-than", metavar="DAYS", type=int, help="Only files older than N days")
    parser.add_argument("--newer-than", metavar="DAYS", type=int, help="Only files newer than N days")
    parser.add_argument("--ignore",     metavar="PATTERN", nargs="+",
                        help="Glob patterns to skip (e.g. '*.tmp' '~*')")

    # Output
    parser.add_argument("--log",         action="store_true", help="Write organize_log.txt")
    parser.add_argument("--html-report", action="store_true", help="Generate HTML summary report")
    parser.add_argument("--csv-report",  action="store_true", help="Generate CSV summary report")
    parser.add_argument("--progress",    action="store_true", help="Show progress bar (requires tqdm)")

    # Custom rules
    parser.add_argument("--rules", metavar="JSON",
                        help='Keyword rules as JSON: \'[{"contains":"invoice","category":"Finance"}]\'')

    args       = parser.parse_args()
    file_types = load_config(args.config if hasattr(args, "config") else None)

    if args.gui:
        launch_gui(file_types)
        return

    if args.folder:
        folder = os.path.abspath(os.path.expanduser(args.folder))
    else:
        folder = os.path.abspath(os.path.expanduser(
            input("Enter the path to the folder you want to organize: ").strip()
        ))

    if not os.path.exists(folder):
        print(f"Folder not found: {folder}")
        return

    if args.undo:
        undo_last(folder)
        return

    # Tag commands
    if args.tag:
        filename, *tag_names = args.tag
        if not tag_names:
            print("Usage: --tag <filename> <tag1> [tag2 ...]")
        else:
            add_tags(folder, filename, tag_names)
        return

    if args.untag:
        filename, *tag_names = args.untag
        if not tag_names:
            print("Usage: --untag <filename> <tag1> [tag2 ...]")
        else:
            remove_tags(folder, filename, tag_names)
        return

    if args.list_tags:
        list_tags(folder)
        return

    if args.search_tag:
        tags         = load_tags(folder)
        if not tags:
            print("  No tagged files in this folder.")
            return
        search_terms = [t.lower() for t in args.search_tag]
        results      = {
            k: v for k, v in tags.items()
            if all(term in [t.lower() for t in v] for term in search_terms)
        }
        label = " + ".join(f"'{t}'" for t in search_terms)
        if not results:
            print(f"  No files found tagged with {label}.")
        else:
            print(f"\n--- Files tagged with {label} ---")
            for key, tag_list in sorted(results.items()):
                abs_path = os.path.join(folder, key)
                exists   = "✓" if os.path.exists(abs_path) else "✗ missing"
                print(f"  [{exists}]  {key:<50}  [{', '.join(sorted(tag_list))}]")
            print(f"\n  {len(results)} file{'s' if len(results) != 1 else ''} found.")
        return

    if args.scan or args.scan_recursive:
        results = scan_suspicious(folder, recursive=args.scan_recursive)
        print_scan_results(results, folder)
        return

    # Parse filters
    min_size   = parse_size(args.min_size)                         if args.min_size   else None
    max_size   = parse_size(args.max_size)                         if args.max_size   else None
    older_than = datetime.now() - timedelta(days=args.older_than)  if args.older_than else None
    newer_than = datetime.now() - timedelta(days=args.newer_than)  if args.newer_than else None

    ignore_patterns = list(DEFAULT_IGNORE_PATTERNS)
    if args.ignore:
        ignore_patterns.extend(args.ignore)

    custom_rules = []
    if args.rules:
        try:
            custom_rules = json.loads(args.rules)
        except json.JSONDecodeError as e:
            print(f"Invalid --rules JSON: {e}"); return

    if args.interactive and args.dry_run:
        print("Note: --interactive has no effect in --dry-run mode.")

    if args.stats_only:
        s = stats_only(folder, file_types, recursive=args.recursive,
                       ignore_patterns=ignore_patterns,
                       min_size=min_size, max_size=max_size,
                       older_than=older_than, newer_than=newer_than)
        print_stats_only(s)
        return

    logger   = setup_logger(folder) if args.log else None
    progress = None

    cfg = OrganizerConfig(
        dry_run=args.dry_run,
        recursive=args.recursive,
        rename=args.rename,
        by_date=args.by_date,
        copy_mode=args.copy,
        interactive=args.interactive,
        verify=args.verify,
        keep_duplicate=args.keep_duplicate,
        ignore_patterns=ignore_patterns,
        custom_rules=custom_rules,
        min_size=min_size,
        max_size=max_size,
        older_than=older_than,
        newer_than=newer_than,
        filter_tags=args.filter_tag or [],
        logger=logger,
        progress=progress,
    )

    if args.watch:
        watch_folder(folder, file_types, cfg)
        return

    if args.progress:
        if TQDM_AVAILABLE:
            progress = tqdm(total=None, unit="file", desc="Organizing")
        else:
            print("tqdm not installed. Run: pip install tqdm  (continuing without progress bar)")
    cfg.progress = progress

    stats, moves_log = organize_folder(folder, file_types, cfg)

    if progress:
        progress.close()

    if not cfg.dry_run and not cfg.copy_mode and moves_log:
        save_history(moves_log, folder)

    if args.html_report:
        generate_html_report(moves_log, stats, folder, dry_run=cfg.dry_run)
    if args.csv_report:
        generate_csv_report(moves_log, stats, folder, dry_run=cfg.dry_run)

    print_stats(stats, dry_run=cfg.dry_run)
    print("Done!")


if __name__ == "__main__":
    main()
