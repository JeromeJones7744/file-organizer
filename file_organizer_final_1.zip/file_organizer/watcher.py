"""
watcher.py — Real-time folder monitoring using watchdog.
Auto-organizes files as they are added to the watched folder.
"""

import os
import time
import shutil

from .constants import OrganizerConfig
from .core import organize_folder, print_stats
from .history import save_history

# Optional watchdog import
try:
    from watchdog.observers import Observer
    from watchdog.events import FileSystemEventHandler
    WATCHDOG_AVAILABLE = True
except ImportError:
    WATCHDOG_AVAILABLE = False
    FileSystemEventHandler = object


class FolderHandler(FileSystemEventHandler):
    def __init__(self, folder_path, file_types, cfg: OrganizerConfig):
        self.folder_path = folder_path
        self.file_types  = file_types
        self.cfg         = cfg

    def on_created(self, event):
        if not event.is_directory:
            path      = event.src_path
            prev_size = -1
            # Wait until file size stabilises (file is done writing)
            for _ in range(10):
                try:
                    curr_size = os.path.getsize(path)
                except OSError:
                    curr_size = -1
                if curr_size == prev_size and curr_size >= 0:
                    break
                prev_size = curr_size
                time.sleep(0.3)

            filename = os.path.basename(path)
            if not filename.startswith("."):
                try:
                    stats, moves_log = organize_folder(
                        self.folder_path, self.file_types, self.cfg,
                        target_file=filename,
                    )
                    if moves_log and not self.cfg.copy_mode and not self.cfg.dry_run:
                        save_history(moves_log, self.folder_path)
                    print_stats(stats)
                except (OSError, shutil.Error) as exc:
                    print(f"  Watch mode error on '{filename}': {exc}")
                    if self.cfg.logger:
                        self.cfg.logger.error(f"Watch mode error on '{filename}': {exc}")


def watch_folder(folder_path, file_types, cfg: OrganizerConfig):
    """Start watching folder_path and organize files as they arrive."""
    if not WATCHDOG_AVAILABLE:
        print("watchdog is not installed. Run: pip install watchdog")
        return
    handler  = FolderHandler(folder_path, file_types, cfg)
    observer = Observer()
    observer.schedule(handler, folder_path, recursive=False)
    observer.start()
    print(f"Watching '{folder_path}' for new files... Press Ctrl+C to stop.")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
    observer.join()
