"""
file_organizer — A Python tool for organizing files by type.

Usage:
    python -m file_organizer ~/Downloads
    python -m file_organizer ~/Downloads --dry-run
    python -m file_organizer ~/Downloads --gui
"""

from .constants import OrganizerConfig, DEFAULT_FILE_TYPES
from .core import (
    organize_folder,
    passes_filters,
    get_file_hash,
    resolve_duplicate_auto,
    stats_only,
    print_stats,
    print_stats_only,
    setup_logger,
    load_config,
)
from .tags import (
    add_tags,
    remove_tags,
    list_tags,
    load_tags,
    save_tags,
    update_tags_on_move,
    get_tagged_files,
)
from .history import save_history, undo_last
from .reports import generate_html_report, generate_csv_report
from .scanner import scan_suspicious, print_scan_results
from .cli import main

__all__ = [
    "OrganizerConfig",
    "DEFAULT_FILE_TYPES",
    "organize_folder",
    "passes_filters",
    "get_file_hash",
    "resolve_duplicate_auto",
    "stats_only",
    "print_stats",
    "add_tags",
    "remove_tags",
    "list_tags",
    "load_tags",
    "update_tags_on_move",
    "get_tagged_files",
    "save_history",
    "undo_last",
    "generate_html_report",
    "generate_csv_report",
    "scan_suspicious",
    "main",
]
