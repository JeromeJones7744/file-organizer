"""
tags.py — User-defined file tagging system.
Tags are stored in .organize_tags.json using relative paths as keys.
"""

import os
import json

from .constants import TAGS_FILE


def _tags_path(folder_path):
    return os.path.join(folder_path, TAGS_FILE)


def _rel(folder_path, file_path):
    """Relative path key used in tag DB."""
    return os.path.relpath(os.path.abspath(file_path), os.path.abspath(folder_path))


def load_tags(folder_path):
    """Load tag DB. Returns dict of {relative_path: [tag, ...]}."""
    path = _tags_path(folder_path)
    if not os.path.exists(path):
        return {}
    with open(path) as f:
        try:
            return json.load(f)
        except json.JSONDecodeError:
            return {}


def save_tags(folder_path, tags):
    """Persist tag DB, pruning empty entries."""
    tags = {k: v for k, v in tags.items() if v}
    with open(_tags_path(folder_path), "w") as f:
        json.dump(tags, f, indent=2, sort_keys=True)


def _resolve_tag_key(folder_path, filename, tags):
    """Find an existing tag DB key that matches filename (bare name or rel path)."""
    # Exact key match first
    if filename in tags:
        return filename
    # Match by basename — warn if ambiguous
    matches = [key for key in tags
               if os.path.basename(key) == os.path.basename(filename)]
    if len(matches) == 1:
        return matches[0]
    if len(matches) > 1:
        print(f"  Ambiguous filename '{os.path.basename(filename)}' matches multiple tagged files:")
        for m in sorted(matches):
            print(f"    {m}")
        print("  Use the relative path (e.g. 'Documents/report.pdf') to be specific.")
        return None
    return None


def add_tags(folder_path, filename, new_tags):
    """Add tags to a file. filename may be a bare name or relative path."""
    tags = load_tags(folder_path)
    key = _resolve_tag_key(folder_path, filename, tags)
    if key is None:
        candidate = os.path.join(folder_path, filename)
        if os.path.exists(candidate):
            key = filename
        else:
            print(f"  File not found in '{folder_path}': {filename}")
            return
    existing = tags.get(key, [])
    added = []
    for t in new_tags:
        t = t.lower().strip()
        if t and t not in existing:
            existing.append(t)
            added.append(t)
    tags[key] = existing
    save_tags(folder_path, tags)
    if added:
        print(f"  Tagged '{key}': {', '.join(added)}")
    else:
        print(f"  No new tags added (already present).")


def remove_tags(folder_path, filename, del_tags):
    """Remove specific tags from a file."""
    tags = load_tags(folder_path)
    key = _resolve_tag_key(folder_path, filename, tags)
    if key is None or key not in tags:
        print(f"  No tags found for: {filename}")
        return
    before = set(tags[key])
    tags[key] = [t for t in tags[key] if t not in [d.lower() for d in del_tags]]
    removed = before - set(tags[key])
    save_tags(folder_path, tags)
    if removed:
        print(f"  Removed tags from '{key}': {', '.join(sorted(removed))}")
    else:
        print(f"  None of those tags were present on '{key}'.")


def list_tags(folder_path, filter_tag=None):
    """Print all tagged files, optionally filtered by a tag."""
    tags = load_tags(folder_path)
    if not tags:
        print("  No tagged files.")
        return
    results = {k: v for k, v in tags.items()
               if filter_tag is None or filter_tag.lower() in [t.lower() for t in v]}
    if not results:
        print(f"  No files tagged '{filter_tag}'.")
        return
    header = f"Tagged files (filter: '{filter_tag}')" if filter_tag else "All tagged files"
    print(f"\n--- {header} ---")
    for key, tag_list in sorted(results.items()):
        print(f"  {key:<50}  [{', '.join(sorted(tag_list))}]")
    print()


def update_tags_on_move(folder_path, src_path, dest_path):
    """Rewrite tag DB key when a file is moved. Called after a successful move."""
    tags = load_tags(folder_path)
    old_key = _rel(folder_path, src_path)
    new_key = _rel(folder_path, dest_path)
    if old_key in tags:
        tags[new_key] = tags.pop(old_key)
        save_tags(folder_path, tags)


def get_tagged_files(folder_path, filter_tags):
    """Return set of absolute paths for files matching ALL given tags."""
    if not filter_tags:
        return None  # None = no filter active
    tags = load_tags(folder_path)
    matched = set()
    for key, tag_list in tags.items():
        tag_set = {t.lower() for t in tag_list}
        if all(ft.lower() in tag_set for ft in filter_tags):
            abs_path = os.path.abspath(os.path.join(folder_path, key))
            matched.add(abs_path)
    return matched
