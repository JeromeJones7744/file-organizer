"""
constants.py — Shared constants and OrganizerConfig dataclass.
No imports from other project modules — this is the foundation layer.
"""

import logging
from datetime import datetime
from dataclasses import dataclass, field
from typing import List, Optional

# ---------------------------------------------------------------------------
# Extension definitions
# ---------------------------------------------------------------------------
SUSPICIOUS_EXTENSIONS = {
    "Executable":    [".exe", ".com", ".scr", ".pif"],
    "Script":        [".bat", ".cmd", ".vbs", ".vbe", ".js", ".jse",
                      ".ps1", ".psm1", ".psd1", ".ws", ".wsh", ".wsf", ".hta"],
    "System/Driver": [".dll", ".sys", ".drv"],
    "Installer":     [".msi", ".msp"],
    "Registry":      [".reg"],
    "Java":          [".jar"],
    "MacroDoc":      [".xlsm", ".docm", ".pptm", ".xlam"],
    "DiskImage":     [".iso", ".img"],
}

DEFAULT_FILE_TYPES = {
    "Images":    [".jpg", ".jpeg", ".png", ".gif", ".bmp", ".svg", ".webp"],
    "Videos":    [".mp4", ".mov", ".avi", ".mkv", ".wmv"],
    "Documents": [".pdf", ".doc", ".docx", ".txt", ".xls", ".xlsx", ".pptx"],
    "Music":     [".mp3", ".wav", ".aac", ".flac"],
    "Archives":  [".zip", ".tar", ".gz", ".rar", ".7z"],
    "Code":      [".py", ".js", ".ts", ".html", ".css", ".java", ".c", ".cpp"],
}

HISTORY_FILE         = ".organize_history.json"
TAGS_FILE            = ".organize_tags.json"
MAX_HISTORY_SESSIONS = 50
LOG_FILE             = "organize_log.txt"

DEFAULT_IGNORE_PATTERNS = [
    "thumbs.db", "desktop.ini", ".DS_Store", "*.tmp", "*.temp", "~*"
]


# ---------------------------------------------------------------------------
# Organizer configuration dataclass
# ---------------------------------------------------------------------------
@dataclass
class OrganizerConfig:
    dry_run:         bool = False
    recursive:       bool = False
    rename:          bool = False
    by_date:         bool = False
    copy_mode:       bool = False
    interactive:     bool = False
    verify:          bool = False
    keep_duplicate:  str  = "route"   # "route" | "newest" | "oldest" | "ask"
    ignore_patterns: List[str] = field(default_factory=lambda: list(DEFAULT_IGNORE_PATTERNS))
    custom_rules:    List[dict] = field(default_factory=list)
    min_size:        Optional[int] = None
    max_size:        Optional[int] = None
    older_than:      Optional[datetime] = None
    newer_than:      Optional[datetime] = None
    filter_tags:     List[str] = field(default_factory=list)
    logger:          Optional[logging.Logger] = None
    progress:        object = None   # tqdm instance or None
