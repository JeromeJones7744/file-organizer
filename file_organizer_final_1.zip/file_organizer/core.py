"""
core.py — Core file organization logic.
Imports from constants and tags; nothing imports from core except gui and cli.
"""

import os
import json
import shutil
import hashlib
import fnmatch
import logging
from datetime import datetime

from .constants import (
    OrganizerConfig,
    DEFAULT_FILE_TYPES,
    DEFAULT_IGNORE_PATTERNS,
    LOG_FILE, HISTORY_FILE, TAGS_FILE,
)
from .tags import get_tagged_files, update_tags_on_move


# ---------------------------------------------------------------------------
# Config loader
# ---------------------------------------------------------------------------
def load_config(config_path):
    """Load custom file type categories from JSON, or return defaults."""
    if config_path and os.path.exists(config_path):
        with open(config_path) as f:
            return json.load(f)
    return DEFAULT_FILE_TYPES


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def get_file_hash(filepath):
    """MD5 hash of a file, read in 8KB chunks to handle large files."""
    h = hashlib.md5()
    with open(filepath, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def get_timestamped_name(filename):
    """Prefix a filename with today's date: YYYY-MM-DD_filename.ext"""
    timestamp = datetime.now().strftime("%Y-%m-%d_")
    name, ext = os.path.splitext(filename)
    return f"{timestamp}{name}{ext}"


def get_date_subfolder(filepath):
    """Return YYYY/MonthName based on file mtime."""
    dt = datetime.fromtimestamp(os.path.getmtime(filepath))
    return os.path.join(str(dt.year), dt.strftime("%B"))


def human_size(nbytes):
    """Convert bytes to a human-readable string."""
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if nbytes < 1024:
            return f"{nbytes:.1f} {unit}"
        nbytes /= 1024
    return f"{nbytes:.1f} PB"


def setup_logger(folder_path):
    """Create (or retrieve) a file logger for the managed folder."""
    from .constants import LOG_FILE
    log_path    = os.path.join(folder_path, LOG_FILE)
    logger_name = f"organizer_{os.path.abspath(folder_path)}"
    logger      = logging.getLogger(logger_name)
    logger.setLevel(logging.INFO)
    if not logger.handlers:
        h = logging.FileHandler(log_path)
        h.setFormatter(logging.Formatter("%(asctime)s - %(message)s"))
        logger.addHandler(h)
    return logger


def matches_ignore(filename, patterns):
    """Return True if filename matches any ignore glob pattern."""
    lower = filename.lower()
    return any(fnmatch.fnmatch(lower, p.lower()) for p in patterns)


def passes_filters(file_path, min_size=None, max_size=None,
                   older_than=None, newer_than=None):
    """Return True if file passes all size and date filters."""
    try:
        stat = os.stat(file_path)
    except OSError:
        return False
    size  = stat.st_size
    mtime = datetime.fromtimestamp(stat.st_mtime)
    if min_size   is not None and size  < min_size:    return False
    if max_size   is not None and size  > max_size:    return False
    if older_than is not None and mtime >= older_than: return False
    if newer_than is not None and mtime <= newer_than: return False
    return True


def apply_custom_rules(filename, custom_rules):
    """Return a category from keyword rules, or None."""
    lower = filename.lower()
    for rule in (custom_rules or []):
        kw = rule.get("contains", "").lower()
        if kw and kw in lower:
            return rule.get("category")
    return None


def verify_copy(src, dest):
    """Return True if src and dest have matching MD5 hashes."""
    try:
        return get_file_hash(src) == get_file_hash(dest)
    except OSError as exc:
        print(f"  WARNING: Could not verify copy — {exc}")
        return False


def describe_duplicate_pair(src_path, dest_path):
    """Print side-by-side size and date info for two files."""
    def info(p):
        s = os.stat(p)
        return human_size(s.st_size), datetime.fromtimestamp(s.st_mtime).strftime("%Y-%m-%d %H:%M")
    ss, sm = info(src_path)
    ds, dm = info(dest_path)
    print(f"    Incoming : {os.path.basename(src_path):<40}  {ss:>10}  {sm}")
    print(f"    Existing : {os.path.basename(dest_path):<40}  {ds:>10}  {dm}")


def resolve_duplicate_auto(src_path, dest_path, keep="newest"):
    """Return 'keep_src' or 'keep_dest' based on modification time."""
    src_t  = os.path.getmtime(src_path)
    dest_t = os.path.getmtime(dest_path)
    if keep == "newest":
        return "keep_src" if src_t > dest_t else "keep_dest"
    return "keep_src" if src_t < dest_t else "keep_dest"


# ---------------------------------------------------------------------------
# Stats-only scan
# ---------------------------------------------------------------------------
def stats_only(folder_path, file_types, recursive=False, ignore_patterns=None,
               min_size=None, max_size=None, older_than=None, newer_than=None):
    """Count files by category without moving anything."""
    ignore_patterns = ignore_patterns or DEFAULT_IGNORE_PATTERNS
    stats = {}

    def _scan(dirpath):
        try:
            entries = os.listdir(dirpath)
        except PermissionError:
            return
        for name in entries:
            full = os.path.join(dirpath, name)
            if os.path.isdir(full):
                if recursive:
                    _scan(full)
                continue
            if name.startswith(".") or name in (LOG_FILE, HISTORY_FILE):
                continue
            if matches_ignore(name, ignore_patterns):
                continue
            if not passes_filters(full, min_size, max_size, older_than, newer_than):
                continue
            _, ext = os.path.splitext(name)
            cat = "Other"
            for c, exts in file_types.items():
                if ext.lower() in exts:
                    cat = c
                    break
            if cat not in stats:
                stats[cat] = {"count": 0, "bytes": 0}
            stats[cat]["count"] += 1
            stats[cat]["bytes"] += os.path.getsize(full)

    _scan(folder_path)
    return stats


def print_stats_only(stats):
    """Print stats-only results."""
    if not stats:
        print("\nNo files found.")
        return
    print("\n--- File Count by Type (no files moved) ---")
    tc = tb = 0
    for cat, data in sorted(stats.items()):
        c, b = data["count"], data["bytes"]
        print(f"  {cat:<15} {c:>5} file{'s' if c != 1 else ''}   {human_size(b):>10}")
        tc += c; tb += b
    print(f"  {'Total':<15} {tc:>5} files       {human_size(tb):>10}")


def print_stats(stats, dry_run=False):
    """Print end-of-run summary."""
    if not stats:
        label = "previewed" if dry_run else "moved"
        print(f"\nNo files were {label}.")
        return
    label = "Would move" if dry_run else "Moved"
    print(f"\n--- Summary ({label}) ---")
    for category, count in sorted(stats.items()):
        print(f"  {category:<15} {count} file{'s' if count != 1 else ''}")
    total = sum(stats.values())
    print(f"  {'Total':<15} {total} file{'s' if total != 1 else ''}")


# ---------------------------------------------------------------------------
# Core organizer
# ---------------------------------------------------------------------------
def organize_folder(folder_path, file_types, cfg: OrganizerConfig,
                    stats=None, moves_log=None, target_file=None, root_folder=None):
    """
    Organize files in folder_path into category subfolders.
    Recursively called for subdirectories when cfg.recursive is True.
    """
    if stats     is None: stats     = {}
    if moves_log is None: moves_log = []
    if root_folder is None:
        root_folder = os.path.abspath(folder_path)

    try:
        filenames = [target_file] if target_file else os.listdir(folder_path)
    except PermissionError:
        print(f"  Permission denied: {folder_path}")
        return stats, moves_log

    for filename in filenames:
        file_path = os.path.join(folder_path, filename)

        if os.path.isdir(file_path):
            if cfg.recursive:
                organize_folder(file_path, file_types, cfg, stats, moves_log, root_folder=root_folder)
            continue

        if filename.startswith(".") or filename in (LOG_FILE, HISTORY_FILE, TAGS_FILE):
            continue
        if matches_ignore(filename, cfg.ignore_patterns):
            continue
        if not passes_filters(file_path, cfg.min_size, cfg.max_size,
                              cfg.older_than, cfg.newer_than):
            continue

        # Tag filter: skip files that don't match all required tags
        if cfg.filter_tags:
            tagged = get_tagged_files(root_folder, cfg.filter_tags)
            if tagged is not None and os.path.abspath(file_path) not in tagged:
                continue

        _, ext = os.path.splitext(filename)
        ext = ext.lower()

        # Category: custom rules first, then extension map
        category = apply_custom_rules(filename, cfg.custom_rules)
        if category is None:
            category = "Other"
            for cat, extensions in file_types.items():
                if ext in extensions:
                    category = cat
                    break

        # Skip if already inside the correct category folder
        current_dir    = os.path.abspath(folder_path)
        rel_dir        = os.path.relpath(current_dir, root_folder)
        relative_parts = [] if rel_dir == "." else rel_dir.split(os.sep)
        if category in relative_parts:
            continue

        dest_folder      = os.path.join(folder_path, category)
        base_dest_folder = dest_folder
        if cfg.by_date:
            dest_folder = os.path.join(dest_folder, get_date_subfolder(file_path))

        # Duplicate detection: search entire category folder tree
        check_path = None
        if os.path.isdir(base_dest_folder):
            for _root, _dirs, _files in os.walk(base_dest_folder):
                if filename in _files:
                    check_path = os.path.join(_root, filename)
                    break

        dest_filename = get_timestamped_name(filename) if cfg.rename else filename
        dest_path     = os.path.join(dest_folder, dest_filename)
        _file_to_delete = None

        if check_path is not None:
            src_hash  = get_file_hash(file_path)
            dest_hash = get_file_hash(check_path)
            if src_hash == dest_hash:
                if cfg.keep_duplicate == "route":
                    dest_folder   = os.path.join(folder_path, "Duplicates")
                    dest_path     = os.path.join(dest_folder, dest_filename)
                    category      = "Duplicates"
                elif cfg.keep_duplicate in ("newest", "oldest"):
                    decision = resolve_duplicate_auto(file_path, check_path, cfg.keep_duplicate)
                    if decision == "keep_dest":
                        print(f"  Skipping duplicate (keeping existing): {filename}")
                        if cfg.progress: cfg.progress.update(1)
                        continue
                    else:
                        _file_to_delete = check_path
                elif cfg.keep_duplicate == "ask":
                    print(f"\n  Duplicate: {filename}")
                    describe_duplicate_pair(file_path, check_path)
                    choice = input("  Keep [i]ncoming / [e]xisting / [r]oute to Duplicates? ").strip().lower()
                    if choice == "e":
                        if cfg.progress: cfg.progress.update(1)
                        continue
                    elif choice == "r":
                        dest_folder = os.path.join(folder_path, "Duplicates")
                        dest_path   = os.path.join(dest_folder, dest_filename)
                        category    = "Duplicates"
            else:
                # Same name, different content — conflict rename
                base, file_ext = os.path.splitext(dest_filename)
                counter   = 1
                candidate = f"{base}_conflict_{counter}{file_ext}"
                while os.path.exists(os.path.join(dest_folder, candidate)):
                    counter  += 1
                    candidate = f"{base}_conflict_{counter}{file_ext}"
                dest_filename = candidate
                dest_path     = os.path.join(dest_folder, dest_filename)

        # Interactive confirmation
        if cfg.interactive and not cfg.dry_run:
            verb = "Copy" if cfg.copy_mode else "Move"
            ans  = input(f"  {verb} '{filename}' -> {category}/{dest_filename}? [y/N] ").strip().lower()
            if ans != "y":
                if cfg.progress: cfg.progress.update(1)
                continue

        if cfg.dry_run:
            verb = "copy" if cfg.copy_mode else "move"
            msg  = f"[DRY RUN] Would {verb} '{filename}' -> {category}/{dest_filename}"
            print(msg)
            if cfg.logger: cfg.logger.info(msg)
            stats[category] = stats.get(category, 0) + 1
            moves_log.append({"src": file_path, "dest": dest_path})
        else:
            try:
                os.makedirs(dest_folder, exist_ok=True)
                if cfg.copy_mode:
                    src_hash_before = get_file_hash(file_path) if cfg.verify else None
                    shutil.copy2(file_path, dest_path)
                    if cfg.verify and get_file_hash(dest_path) != src_hash_before:
                        print(f"  WARNING: Checksum mismatch after copy of '{filename}'!")
                        if cfg.logger: cfg.logger.warning(f"Checksum mismatch: {filename}")
                else:
                    src_hash_before = get_file_hash(file_path) if cfg.verify else None
                    shutil.move(file_path, dest_path)
                    if cfg.verify and (not os.path.exists(dest_path) or
                                       get_file_hash(dest_path) != src_hash_before):
                        print(f"  WARNING: Verification failed after move of '{filename}'!")
                        if cfg.logger: cfg.logger.warning(f"Verification failed: {filename}")
                    if (_file_to_delete and os.path.exists(_file_to_delete)
                        and os.path.abspath(_file_to_delete) != os.path.abspath(dest_path)):
                        os.remove(_file_to_delete)
                    # Keep tags in sync with new path
                    update_tags_on_move(root_folder, file_path, dest_path)

                verb = "Copied" if cfg.copy_mode else "Moved"
                msg  = f"{verb} '{filename}' -> {category}/{dest_filename}"
                print(msg)
                if cfg.logger: cfg.logger.info(msg)
                stats[category] = stats.get(category, 0) + 1
                moves_log.append({"src": file_path, "dest": dest_path})

            except (OSError, shutil.Error) as exc:
                print(f"  ERROR on '{filename}': {exc}")
                if cfg.logger: cfg.logger.error(f"Failed on '{filename}': {exc}")

        if cfg.progress: cfg.progress.update(1)

    return stats, moves_log
