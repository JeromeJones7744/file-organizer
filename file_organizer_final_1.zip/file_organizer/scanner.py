"""
scanner.py — Suspicious file extension scanner.
Detects potentially dangerous file types without moving anything.
"""

import os

from .constants import SUSPICIOUS_EXTENSIONS


def scan_suspicious(folder_path, recursive=False):
    """Scan folder for files with suspicious extensions. Returns list of findings."""
    ext_to_category = {
        ext: cat
        for cat, exts in SUSPICIOUS_EXTENSIONS.items()
        for ext in exts
    }
    results = []

    def _scan_dir(dirpath):
        try:
            entries = os.listdir(dirpath)
        except PermissionError:
            return
        for name in entries:
            full = os.path.join(dirpath, name)
            if os.path.isdir(full):
                if recursive:
                    _scan_dir(full)
            else:
                ext_lower = os.path.splitext(name)[1].lower()
                if ext_lower in ext_to_category:
                    results.append({
                        "path":      full,
                        "filename":  name,
                        "extension": ext_lower,
                        "category":  ext_to_category[ext_lower],
                    })

    _scan_dir(folder_path)
    return results


def print_scan_results(results, folder_path):
    """Print scan findings grouped by category."""
    if not results:
        print("No suspicious files found.")
        return
    print(f"\n--- Suspicious Files Found: {len(results)} ---")
    by_category = {}
    for r in results:
        by_category.setdefault(r["category"], []).append(r)
    for category, items in sorted(by_category.items()):
        print(f"\n  [{category}]")
        for item in items:
            print(f"    {os.path.relpath(item['path'], folder_path)}")
    print()
