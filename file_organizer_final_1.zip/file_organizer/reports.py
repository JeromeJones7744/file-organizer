"""
reports.py — HTML and CSV report generation.
Called after an organize run to summarize what happened.
"""

import os
import csv
import html as html_module
from datetime import datetime


def generate_html_report(moves_log, stats, folder_path, dry_run=False):
    """Write a styled HTML summary report to the managed folder."""
    report_path = os.path.join(folder_path, "organize_report.html")
    mode = "DRY RUN PREVIEW" if dry_run else "COMPLETED"
    ts   = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    rows = "".join(
        f"<tr><td>{html_module.escape(os.path.basename(m['src']))}</td>"
        f"<td>{html_module.escape(os.path.relpath(m['dest'], folder_path))}</td></tr>\n"
        for m in moves_log
    )
    stat_rows = "".join(
        f"<tr><td>{html_module.escape(cat)}</td><td>{count}</td></tr>\n"
        for cat, count in sorted(stats.items())
    )
    total = sum(stats.values())

    move_label = "Previewed Files (Dry Run)" if dry_run else "File Moves"
    col_label  = "Would Move To" if dry_run else "Destination"

    html = f"""<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><title>File Organizer Report</title>
<style>
  body{{font-family:Arial,sans-serif;margin:32px;color:#222}}
  h1{{color:#2e7d32}} h2{{color:#555;margin-top:28px}}
  table{{border-collapse:collapse;width:100%;max-width:860px}}
  th,td{{border:1px solid #ddd;padding:8px 12px;text-align:left}}
  th{{background:#f5f5f5}} tr:nth-child(even){{background:#fafafa}}
  .badge{{display:inline-block;padding:2px 10px;border-radius:12px;
    background:{'#fff3e0' if dry_run else '#e8f5e9'};
    color:{'#e65100' if dry_run else '#2e7d32'};font-weight:bold;font-size:.9em}}
  .note{{font-style:italic;color:#888;font-size:.9em}}
</style></head>
<body>
<h1>File Organizer Report</h1>
<p>Generated: {ts} &nbsp;<span class="badge">{mode}</span></p>
<p>Folder: <code>{html_module.escape(folder_path)}</code></p>
{'<p class="note">This is a dry-run preview. No files were actually moved.</p>' if dry_run else ''}
<h2>Summary by Category {'(Preview)' if dry_run else ''}</h2>
<table><tr><th>Category</th><th>{'Would Move' if dry_run else 'Files Moved'}</th></tr>
{stat_rows}<tr><th>Total</th><th>{total}</th></tr></table>
<h2>{move_label} ({len(moves_log)})</h2>
<table><tr><th>File</th><th>{col_label}</th></tr>
{rows if rows else '<tr><td colspan="2">No files moved.</td></tr>'}
</table></body></html>"""

    with open(report_path, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"  HTML report -> {report_path}")


def generate_csv_report(moves_log, stats, folder_path, dry_run=False):
    """Write a CSV summary report to the managed folder."""
    report_path = os.path.join(folder_path, "organize_report.csv")
    with open(report_path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["type", "key", "value"])
        w.writerow(["meta", "generated", datetime.now().isoformat()])
        w.writerow(["meta", "dry_run",   str(dry_run)])
        w.writerow(["meta", "folder",    folder_path])
        for cat, count in sorted(stats.items()):
            w.writerow(["stat", cat, count])
        w.writerow(["stat", "Total", sum(stats.values())])
        for m in moves_log:
            w.writerow(["move", m["src"], m["dest"]])
    print(f"  CSV  report -> {report_path}")
