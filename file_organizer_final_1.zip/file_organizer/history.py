"""
history.py — Session history and undo support.
Saves move logs to .organize_history.json and restores them on undo.
"""

import os
import json
import shutil
from datetime import datetime

from .constants import HISTORY_FILE, MAX_HISTORY_SESSIONS


def save_history(moves, folder_path):
    """Append a session's move log to the history file."""
    history_path = os.path.join(folder_path, HISTORY_FILE)
    history = {"sessions": []}
    if os.path.exists(history_path):
        with open(history_path) as f:
            try:
                history = json.load(f)
            except json.JSONDecodeError:
                pass
    history["sessions"].append({
        "timestamp": datetime.now().isoformat(),
        "moves": moves,
    })
    history["sessions"] = history["sessions"][-MAX_HISTORY_SESSIONS:]
    with open(history_path, "w") as f:
        json.dump(history, f, indent=2)


def undo_last(folder_path):
    """Reverse the most recent organize session."""
    history_path = os.path.join(folder_path, HISTORY_FILE)
    if not os.path.exists(history_path):
        print("No history found. Nothing to undo.")
        return
    with open(history_path) as f:
        try:
            history = json.load(f)
        except json.JSONDecodeError:
            print("History file is corrupted.")
            return
    if not history.get("sessions"):
        print("No sessions to undo.")
        return

    last_session = history["sessions"].pop()
    restored = 0
    for move in reversed(last_session["moves"]):
        src, dest = move["src"], move["dest"]
        if not os.path.exists(dest):
            print(f"Skipping '{os.path.basename(dest)}' — file not found at destination")
            continue
        try:
            src_dir = os.path.dirname(src)
            if src_dir:
                os.makedirs(src_dir, exist_ok=True)
            shutil.move(dest, src)
            print(f"Restored '{os.path.basename(src)}'")
            restored += 1
        except OSError as exc:
            print(f"  ERROR restoring '{os.path.basename(src)}': {exc}")

    with open(history_path, "w") as f:
        json.dump(history, f, indent=2)
    print(f"\nUndo complete. Restored {restored} file(s).")
