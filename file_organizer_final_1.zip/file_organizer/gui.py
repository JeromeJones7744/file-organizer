"""
gui.py — Graphical interface using tkinter.
Two-tab layout: Organize tab and Tags tab.
"""

import os
import sys

from .constants import OrganizerConfig
from .core import organize_folder, print_stats, setup_logger
from .tags import add_tags, remove_tags, list_tags
from .history import save_history
from .reports import generate_html_report, generate_csv_report
from .scanner import scan_suspicious, print_scan_results

# Optional tkinter import
try:
    import tkinter as tk
    from tkinter import filedialog, messagebox
    TKINTER_AVAILABLE = True
except ImportError:
    TKINTER_AVAILABLE = False


def launch_gui(file_types):
    if not TKINTER_AVAILABLE:
        print("tkinter is not available on this system.")
        return

    root = tk.Tk()
    root.title("File Organizer")
    root.geometry("650x700")
    root.resizable(False, False)

    # Use ttk Notebook for tabs
    try:
        from tkinter import ttk
        notebook     = ttk.Notebook(root)
        notebook.pack(fill="both", expand=True, padx=8, pady=8)
        organize_tab = ttk.Frame(notebook)
        tags_tab     = ttk.Frame(notebook)
        notebook.add(organize_tab, text="  Organize  ")
        notebook.add(tags_tab,     text="  Tags  ")
    except Exception:
        organize_tab = root
        tags_tab     = None

    # ------------------------------------------------------------------ #
    #  ORGANIZE TAB                                                        #
    # ------------------------------------------------------------------ #
    tk.Label(organize_tab, text="Folder to organize:", anchor="w").pack(fill="x", padx=12, pady=(12, 0))
    row = tk.Frame(organize_tab); row.pack(fill="x", padx=12)
    folder_var = tk.StringVar()
    tk.Entry(row, textvariable=folder_var, width=50).pack(side="left", fill="x", expand=True)

    def browse():
        path = filedialog.askdirectory()
        if path: folder_var.set(path)

    tk.Button(row, text="Browse", command=browse).pack(side="right", padx=(4, 0))

    tk.Label(organize_tab, text="Options:", anchor="w").pack(fill="x", padx=12, pady=(10, 0))
    dry_run_var        = tk.BooleanVar()
    recursive_var      = tk.BooleanVar()
    rename_var         = tk.BooleanVar()
    by_date_var        = tk.BooleanVar()
    copy_mode_var      = tk.BooleanVar()
    verify_var         = tk.BooleanVar()
    log_var            = tk.BooleanVar()
    html_report_var    = tk.BooleanVar()
    csv_report_var     = tk.BooleanVar()
    scan_recursive_var = tk.BooleanVar()
    keep_duplicate_var = tk.StringVar(value="route")

    for label, var in [
        ("Dry run (preview only)",                       dry_run_var),
        ("Recursive (include subfolders)",               recursive_var),
        ("Rename files with date prefix",                rename_var),
        ("Organise into date subfolders (YYYY/Month/)",  by_date_var),
        ("Copy files instead of moving",                 copy_mode_var),
        ("Verify copies with checksum",                  verify_var),
        ("Save log to organize_log.txt",                 log_var),
        ("Generate HTML report",                         html_report_var),
        ("Generate CSV report",                          csv_report_var),
        ("Scan subfolders for suspicious files",         scan_recursive_var),
    ]:
        tk.Checkbutton(organize_tab, text=label, variable=var).pack(anchor="w", padx=24)

    dup_row = tk.Frame(organize_tab); dup_row.pack(anchor="w", padx=24, pady=(4, 0))
    tk.Label(dup_row, text="Duplicate handling:").pack(side="left")
    tk.OptionMenu(dup_row, keep_duplicate_var, "route", "newest", "oldest", "ask").pack(side="left", padx=4)

    filter_row = tk.Frame(organize_tab); filter_row.pack(anchor="w", padx=24, pady=(4, 0))
    tk.Label(filter_row, text="Only organize files tagged:").pack(side="left")
    filter_tag_var = tk.StringVar()
    tk.Entry(filter_row, textvariable=filter_tag_var, width=20).pack(side="left", padx=(4, 0))
    tk.Label(filter_row, text="(space-separated, leave blank for all)", fg="#888").pack(side="left", padx=(4, 0))

    tk.Label(organize_tab, text="Output:", anchor="w").pack(fill="x", padx=12, pady=(8, 0))
    output = tk.Text(organize_tab, height=8, state="disabled",
                     bg="#1e1e1e", fg="#d4d4d4", font=("Courier", 10))
    output.pack(fill="both", expand=True, padx=12, pady=(0, 6))

    class Redirect:
        def write(self, text):
            output.config(state="normal")
            output.insert(tk.END, text)
            output.see(tk.END)
            output.config(state="disabled")
            root.update()
        def flush(self): pass

    def run():
        folder = os.path.abspath(os.path.expanduser(folder_var.get().strip()))
        if not os.path.exists(folder):
            messagebox.showerror("Error", f"Folder not found:\n{folder}"); return
        output.config(state="normal"); output.delete("1.0", tk.END)
        old_stdout = sys.stdout; sys.stdout = Redirect()
        logger     = setup_logger(folder) if log_var.get() else None
        raw_tags   = filter_tag_var.get().strip()
        filter_tags = [t.lower() for t in raw_tags.split() if t] if raw_tags else []
        cfg = OrganizerConfig(
            dry_run=dry_run_var.get(),
            recursive=recursive_var.get(),
            rename=rename_var.get(),
            by_date=by_date_var.get(),
            copy_mode=copy_mode_var.get(),
            verify=verify_var.get(),
            keep_duplicate=keep_duplicate_var.get(),
            filter_tags=filter_tags,
            logger=logger,
        )
        if filter_tags:
            print(f"Tag filter active: {', '.join(filter_tags)}")
        stats, moves_log = organize_folder(folder, file_types, cfg)
        if not cfg.dry_run and not cfg.copy_mode and moves_log:
            save_history(moves_log, folder)
        if html_report_var.get():
            generate_html_report(moves_log, stats, folder, dry_run=cfg.dry_run)
        if csv_report_var.get():
            generate_csv_report(moves_log, stats, folder, dry_run=cfg.dry_run)
        print_stats(stats, dry_run=cfg.dry_run); print("Done!")
        sys.stdout = old_stdout; output.config(state="disabled")

    def run_scan():
        folder = os.path.abspath(os.path.expanduser(folder_var.get().strip()))
        if not os.path.exists(folder):
            messagebox.showerror("Error", f"Folder not found:\n{folder}"); return
        output.config(state="normal"); output.delete("1.0", tk.END)
        old_stdout = sys.stdout; sys.stdout = Redirect()
        results = scan_suspicious(folder, recursive=scan_recursive_var.get())
        print_scan_results(results, folder)
        sys.stdout = old_stdout; output.config(state="disabled")

    btn_row = tk.Frame(organize_tab); btn_row.pack(pady=6)
    tk.Button(btn_row, text="Organize",        command=run,
              bg="#4CAF50", fg="white", font=("Helvetica", 11, "bold"), pady=4
              ).pack(side="left", padx=4)
    tk.Button(btn_row, text="Scan Suspicious", command=run_scan,
              bg="#e65100", fg="white", font=("Helvetica", 11, "bold"), pady=4
              ).pack(side="left", padx=4)

    # ------------------------------------------------------------------ #
    #  TAGS TAB                                                            #
    # ------------------------------------------------------------------ #
    if tags_tab is not None:
        tk.Label(tags_tab, text="Folder:", anchor="w").pack(fill="x", padx=12, pady=(12, 0))
        tag_folder_row = tk.Frame(tags_tab); tag_folder_row.pack(fill="x", padx=12)
        tag_folder_var = tk.StringVar()

        def _sync_folder(*_):
            tag_folder_var.set(folder_var.get())
        folder_var.trace_add("write", _sync_folder)

        tk.Entry(tag_folder_row, textvariable=tag_folder_var, width=50).pack(side="left", fill="x", expand=True)

        def browse_tag_folder():
            path = filedialog.askdirectory()
            if path: tag_folder_var.set(path)
        tk.Button(tag_folder_row, text="Browse", command=browse_tag_folder).pack(side="right", padx=(4, 0))

        tk.Label(tags_tab, text="File name (or relative path):", anchor="w").pack(fill="x", padx=12, pady=(14, 0))
        tag_file_var = tk.StringVar()
        tk.Entry(tags_tab, textvariable=tag_file_var, width=55).pack(fill="x", padx=12)

        tk.Label(tags_tab, text="Tags (space-separated):", anchor="w").pack(fill="x", padx=12, pady=(8, 0))
        tag_input_var = tk.StringVar()
        tk.Entry(tags_tab, textvariable=tag_input_var, width=55).pack(fill="x", padx=12)

        def _get_tag_folder():
            f = os.path.abspath(os.path.expanduser(tag_folder_var.get().strip()))
            if not os.path.exists(f):
                messagebox.showerror("Error", f"Folder not found:\n{f}")
                return None
            return f

        tag_output_lines = []

        class Redirect_tags:
            def write(self, text):
                tag_output_lines.append(text)
            def flush(self): pass

        tag_console = None  # defined later

        def do_add_tags():
            folder = _get_tag_folder()
            if not folder: return
            fname  = tag_file_var.get().strip()
            tnames = tag_input_var.get().strip().split()
            if not fname or not tnames:
                messagebox.showwarning("Missing input", "Enter a file name and at least one tag.")
                return
            old_stdout = sys.stdout; sys.stdout = Redirect_tags()
            add_tags(folder, fname, tnames)
            sys.stdout = old_stdout
            refresh_tag_list()

        def do_remove_tags():
            folder = _get_tag_folder()
            if not folder: return
            fname  = tag_file_var.get().strip()
            tnames = tag_input_var.get().strip().split()
            if not fname or not tnames:
                messagebox.showwarning("Missing input", "Enter a file name and at least one tag.")
                return
            old_stdout = sys.stdout; sys.stdout = Redirect_tags()
            remove_tags(folder, fname, tnames)
            sys.stdout = old_stdout
            refresh_tag_list()

        tag_btn_row = tk.Frame(tags_tab); tag_btn_row.pack(pady=(8, 0))
        tk.Button(tag_btn_row, text="Add Tags",    command=do_add_tags,
                  bg="#1976D2", fg="white", font=("Helvetica", 10, "bold"), pady=3
                  ).pack(side="left", padx=6)
        tk.Button(tag_btn_row, text="Remove Tags", command=do_remove_tags,
                  bg="#c62828", fg="white", font=("Helvetica", 10, "bold"), pady=3
                  ).pack(side="left", padx=6)

        search_row = tk.Frame(tags_tab); search_row.pack(fill="x", padx=12, pady=(14, 0))
        tk.Label(search_row, text="Search tag:").pack(side="left")
        search_var = tk.StringVar()
        tk.Entry(search_row, textvariable=search_var, width=20).pack(side="left", padx=4)
        tk.Button(search_row, text="Search",   command=lambda: refresh_tag_list(search_var.get().strip())).pack(side="left", padx=2)
        tk.Button(search_row, text="Show All", command=lambda: refresh_tag_list()).pack(side="left", padx=2)

        tk.Label(tags_tab, text="Tagged files:", anchor="w").pack(fill="x", padx=12, pady=(10, 0))
        tag_list_box = tk.Text(tags_tab, height=12, state="disabled",
                               bg="#1e1e1e", fg="#d4d4d4", font=("Courier", 10))
        tag_list_box.pack(fill="both", expand=True, padx=12, pady=(0, 8))

        def refresh_tag_list(filter_tag=None):
            folder = _get_tag_folder()
            if not folder: return
            tag_output_lines.clear()
            old_stdout = sys.stdout; sys.stdout = Redirect_tags()
            list_tags(folder, filter_tag=filter_tag if filter_tag else None)
            sys.stdout = old_stdout
            tag_list_box.config(state="normal")
            tag_list_box.delete("1.0", tk.END)
            tag_list_box.insert(tk.END, "".join(tag_output_lines))
            tag_list_box.config(state="disabled")

        tk.Button(tags_tab, text="Refresh List", command=refresh_tag_list,
                  font=("Helvetica", 9)).pack(pady=(0, 6))

        tag_console = tk.Text(tags_tab, height=4, state="disabled",
                              bg="#111", fg="#aaffaa", font=("Courier", 9))
        tag_console.pack(fill="x", padx=12, pady=(0, 8))

        # Redefine with console output now that tag_console exists
        class Redirect_tags:  # noqa: F811
            def write(self, text):
                tag_output_lines.append(text)
                tag_console.config(state="normal")
                tag_console.insert(tk.END, text)
                tag_console.see(tk.END)
                tag_console.config(state="disabled")
                root.update()
            def flush(self): pass

    root.mainloop()
